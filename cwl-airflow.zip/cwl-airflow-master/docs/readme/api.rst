API
-----------

.. openapi:: ../../cwl_airflow/components/api/openapi/swagger_configuration.yaml